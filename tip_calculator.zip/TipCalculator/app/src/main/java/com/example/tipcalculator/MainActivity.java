package com.example.tipcalculator;

import android.content.Intent;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class MainActivity extends AppCompatActivity {

    //add data members
    private static int LOAD_TIME_OUT = 4000; //4 sec



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                Intent loadingScreen = new Intent(MainActivity.this, FirstPageActivity.class);
                startActivity(loadingScreen);
                finish();
            }
        }, LOAD_TIME_OUT);
    } //end onCreate

} //end MainActivity
