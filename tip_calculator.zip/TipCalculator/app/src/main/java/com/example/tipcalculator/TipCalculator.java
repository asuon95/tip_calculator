package com.example.tipcalculator;


public class TipCalculator {

    //data members
    private double tipTotalFormatted;
    private double billTotalFormatted;
    private int personSelected;
    private double taxRate;
    private double taxAmount;
    private double tipAmount;
    private double subTotalAmount;
    private double tipSplitAmount;
    private double subTotalSplitAmount;
    private double grandTotalSplitAmount;
    private double grandTotalAmount;


    //constructor w/ 4 params
    public TipCalculator(double tipTotalFormatted, double billTotalFormatted, int personSelected, double taxRate) {
        this.tipTotalFormatted = tipTotalFormatted;
        this.billTotalFormatted = billTotalFormatted;
        this.personSelected = personSelected;
        this.taxRate = taxRate;
    }

    //instance method: calculate tips
    public double calTip() {
        tipAmount = Math.round(((tipTotalFormatted/100)*billTotalFormatted)*100.0)/100.0;
        return tipAmount;
    }

    //calculate tax
    public double calTax() {
        taxAmount = Math.round(((taxRate/100)*billTotalFormatted)*100.0)/100.0;
        return taxAmount;
    }


    //calculate tips per person
    public double calTipSplit() {
        tipSplitAmount = Math.round((tipAmount/personSelected)*100.0)/100.0;
        return tipSplitAmount;
    }

    //calculate sub-total per person
    public double calSubTotalSplit() {
        subTotalAmount = Math.round((taxAmount+billTotalFormatted)*100.0)/100.0;
        subTotalSplitAmount = Math.round((subTotalAmount/personSelected)*100.0)/100.0;
        return subTotalSplitAmount;
    }

    //calculate total amount per person with subtotal and tips
    public double calGrandTotalSplit() {
        grandTotalSplitAmount = Math.round((tipSplitAmount+subTotalSplitAmount)*100.0)/100.0;
        return grandTotalSplitAmount;
    }

    //grand total
    public double calGrandTotal(){
        grandTotalAmount = Math.round((tipAmount+taxAmount+billTotalFormatted)*100.0)/100.0;
        return grandTotalAmount;
    }

}
