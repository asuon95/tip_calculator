package com.example.tipcalculator;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;

public class FirstPageActivity extends AppCompatActivity {

    //add data members
    private Button calculateButton;
    private EditText tipEditText;
    private EditText billEditText;
    private EditText personEditText;
    private Spinner dropDown;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_first_page);

        //link data members to resources(activity1)
        calculateButton = findViewById(R.id.calculate_button);
        tipEditText = findViewById(R.id.edit_tip);
        billEditText = findViewById(R.id.edit_bill);
        personEditText = findViewById(R.id.edit_person);
        dropDown = findViewById(R.id.edit_spinner);

        //event listener for "Calculate" button
        calculateButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                //validation for empty string
                // a)get the string values, and b)validate using if else statements
                String billAmount = billEditText.getText().toString();
                String tipAmount = tipEditText.getText().toString();
                String personSelected = personEditText.getText().toString();

                if (billAmount.trim().equals("")) {
                    AlertDialog.Builder builder = new AlertDialog.Builder(FirstPageActivity.this);
                    builder.setTitle("HOLD UP!");
                    builder.setMessage("Please enter the bill amount.").setCancelable(false).setPositiveButton("OK", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            //do nothing
                        }
                    });
                    AlertDialog alert = builder.create();
                    alert.show();
                    return; //loop out
                } else if(tipAmount.trim().equals("")) {
                    AlertDialog.Builder builder = new AlertDialog.Builder(FirstPageActivity.this);
                    builder.setTitle("Hang on!");
                    builder.setMessage("Please enter a tip percentage(or zero if none).").setCancelable(false).setPositiveButton("OK", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            //do nothing
                        }
                    });
                    AlertDialog alert = builder.create();
                    alert.show();
                    return; //loop out
                }else if(personSelected.trim().equals("")) {
                    AlertDialog.Builder builder = new AlertDialog.Builder(FirstPageActivity.this);
                    builder.setTitle("Wait a minute ...");
                    builder.setMessage("Please enter your party size.").setCancelable(false).setPositiveButton("OK", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            //do nothing
                        }
                    });
                    AlertDialog alert = builder.create();
                    alert.show();
                    return; //loop out
                }

                //take strings from EditText
                //note: to get values from a spinner(dropdown box) use getSelectedItem().toString()
                //for regular text boxes use getText().toString()
                //make a SharedPreference obj so that data can be shared with other activities
                SharedPreferences sharedPref = getSharedPreferences("SharedData", Context.MODE_PRIVATE);
                SharedPreferences.Editor editor = sharedPref.edit();
                editor.putString("billstr", billEditText.getText().toString());
                editor.putString("tipstr", tipEditText.getText().toString());
                editor.putString("personstr", personEditText.getText().toString());
                editor.putString("dropDownstr", dropDown.getSelectedItem().toString());
                editor.apply();

                //launch activity_display
                launchActivityDisplay();

            } //end onClicked
        }); //end setOnClickedListener
    } //end onCreate

    //Override the onBackPressed() to display a dialog to confirm exit on back button press
    @Override
    public void onBackPressed(){
        //NOTE: AlertDialog requires a Builder obj to build and create and an AlertDialog obj to show the alert
        AlertDialog.Builder builder = new AlertDialog.Builder(FirstPageActivity.this);
        builder.setTitle("Do you want to exit Bill Me?").setPositiveButton(R.string.ok, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                finish();
            }
        }).setNegativeButton("CANCEL", null); //null means if cancel is clicked then do nothing
        AlertDialog alert = builder.create();
        alert.show();
        return; //loop out
    } //end onBackPressed

    //utilizes a) Intent.class to launch a new Activity(display.class) on method call, and b)transfer data through SharedPreference.class
    public void launchActivityDisplay() {
        Intent loadDisplay = new Intent(this, display.class);
        Intent dataTransfer = new Intent(getApplicationContext(), display.class);
        startActivity(dataTransfer);
        startActivity(loadDisplay);
    } //end launchActivityDisplay
} //end ActivityFirstPage
