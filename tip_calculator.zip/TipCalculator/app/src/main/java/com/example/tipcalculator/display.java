package com.example.tipcalculator;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;


public class display extends AppCompatActivity {

    //create members
    private Button calcAnother;
    private TextView billBTAmount;
    private TextView taxAmount;
    private TextView tipAmount;
    private TextView numPersonAmount;
    private TextView grandTotalAmount;
    private TextView subTotalPersonAmount;
    private TextView tipPersonAmount;
    private TextView totalSplitAmount;
    private double taxRate;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_display);

        //link data members activity2
        billBTAmount = findViewById(R.id.label_billBTAmount);
        taxAmount = findViewById(R.id.label_taxAmount);
        tipAmount = findViewById(R.id.label_tipAmount);
        numPersonAmount = findViewById(R.id.label_numPersonAmount);
        grandTotalAmount = findViewById(R.id.label_grandTotalAmount);
        subTotalPersonAmount = findViewById(R.id.label_subTotalPersonAmount);
        tipPersonAmount = findViewById(R.id.label_tipPersonAmount);
        totalSplitAmount = findViewById(R.id.label_totalSplitPersonAmount);

        //SharedPreferences obj to get data info from Activity1
        SharedPreferences sharedPref = getSharedPreferences("SharedData", Context.MODE_PRIVATE);
        String billstr = sharedPref.getString("billstr", "returns bill input from Activity1");
        String tipstr = sharedPref.getString("tipstr", "returns tip input from Activity1");
        String personstr = sharedPref.getString("personstr", "returns num of person input from Activity1");
        String dropDownstr = sharedPref.getString("dropDownstr", "returns drop down  item from Activity1");

        //convert from strings to double before calculation
        double billTotal = Double.parseDouble(billstr);
        double tipTotal = Double.parseDouble(tipstr);
        int personSelected = Integer.parseInt(personstr);

        //round to 2 decimal places using Math.round()
        double billTotalFormatted = Math.round(billTotal*100.0)/100.0;
        double tipTotalFormatted = Math.round(tipTotal*100.0)/100.0;


        //if-else statements to check for dropDown value selected and match to taxRate
        if (dropDownstr.equalsIgnoreCase("CA")) {
            taxRate = 7.25; //accuracy @2019
        }else if (dropDownstr.equalsIgnoreCase("AZ")) {
            taxRate = 5.6; //accuracy @2019
        }else if(dropDownstr.equalsIgnoreCase("TX")) {
            taxRate = 6.25; //accuracy @2019
        }

        //make an object TipCalculator and call TipCalculator for calculations
        //NOTE: order matters when providing the params
        TipCalculator tipObject = new TipCalculator(tipTotalFormatted, billTotalFormatted, personSelected, taxRate);

        double CalculatedTaxAmount = tipObject.calTax();
        double CalculatedTipAmount = tipObject.calTip();
        double CalculatedGrandTotalAmount = tipObject.calGrandTotal();
        double CalculatedSubTotalPerson = tipObject.calSubTotalSplit();
        double CalculatedTipPerson = tipObject.calTipSplit();
        double CalculatedTotalSplitPerson = tipObject.calGrandTotalSplit();

        //display strings to be shown
        String displayBillBTAmount = "$" + String.valueOf(billTotalFormatted);
        String displayTaxAmount = "$" + String.valueOf(CalculatedTaxAmount);
        String displayTipAmount = "$" + String.valueOf(CalculatedTipAmount);
        String displayNumPerson = String.valueOf(personstr);
        String displayGrandTotal = "$" + String.valueOf(CalculatedGrandTotalAmount);
        String displayTipPerson = "$" + String.valueOf(CalculatedTipPerson);
        String displaySubTotalPerson = "$" + String.valueOf(CalculatedSubTotalPerson);
        String displayTotalSplitPerson = "$" + String.valueOf(CalculatedTotalSplitPerson);

        //setText to display
        billBTAmount.setText(displayBillBTAmount);
        taxAmount.setText(displayTaxAmount);
        tipAmount.setText(displayTipAmount);
        numPersonAmount.setText(displayNumPerson);
        grandTotalAmount.setText(displayGrandTotal);
        tipPersonAmount.setText(displayTipPerson);
        subTotalPersonAmount.setText(displaySubTotalPerson);
        totalSplitAmount.setText(displayTotalSplitPerson);

        //link resources
        calcAnother = findViewById(R.id.button_calcAnother);
        calcAnother.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openFirstPage();
            }
        });
    } //end onCreate

    //sends user back to Activity1 via button clicked
    public void openFirstPage() {
        Intent FirstPage = new Intent(this, FirstPageActivity.class);
        startActivity(FirstPage);
    }
}
